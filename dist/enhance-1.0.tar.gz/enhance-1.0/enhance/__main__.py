from .srcnn import main

main()
